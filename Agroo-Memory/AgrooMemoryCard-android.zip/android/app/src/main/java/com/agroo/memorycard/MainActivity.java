package com.agroo.memorycard;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
