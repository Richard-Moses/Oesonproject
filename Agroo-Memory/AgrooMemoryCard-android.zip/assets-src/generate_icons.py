"""
Generates the Android launcher icon (adaptive foreground + legacy flattened),
the Play Store 512x512 icon, and the 1024x500 feature graphic -- all drawn
programmatically so they match the in-game card-back art (a gold-outlined
black star on a black card) without depending on any external font/image
downloads.
"""
import math
from PIL import Image, ImageDraw, ImageFont

RED = (206, 17, 38, 255)
GOLD = (252, 209, 22, 255)
GREEN = (0, 107, 63, 255)
BLACK_STAR = (12, 11, 9, 255)
PLATE = (21, 19, 15, 255)
PLATE_2 = (5, 4, 3, 255)
CREAM = (247, 243, 232, 255)

OUT = "/home/claude/agroo-memory-android/android/app/src/main/res"


def star_points(cx, cy, outer_r, inner_r, rotation_deg=-90):
    pts = []
    for i in range(10):
        angle = math.radians(rotation_deg + i * 36)
        r = outer_r if i % 2 == 0 else inner_r
        pts.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
    return pts


def rounded_square(draw, box, radius, fill=None, outline=None, width=0):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def draw_star(draw, cx, cy, outer_r, fill, inner_ratio=0.5, rotation=-90):
    pts = star_points(cx, cy, outer_r, outer_r * inner_ratio, rotation)
    draw.polygon(pts, fill=fill)


def icon_card(size, include_background, bg_color=GREEN):
    """The shared visual: an (optionally backgrounded) black card with a gold
    border, thin red ring, and a gold-outlined black star -- centered and
    padded so it survives adaptive-icon masking."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    if include_background:
        d.rectangle([0, 0, size, size], fill=bg_color)

    # Keep all meaningful content inside the safe zone (~66% of full canvas,
    # centered) so circular/squircle/teardrop adaptive masks never clip it.
    card_size = size * 0.60
    half = card_size / 2
    cx, cy = size / 2, size / 2
    card_box = [cx - half, cy - half, cx + half, cy + half]

    red_pad = size * 0.018
    rounded_square(d, [card_box[0] - red_pad, card_box[1] - red_pad,
                        card_box[2] + red_pad, card_box[3] + red_pad],
                    radius=card_size * 0.16, fill=RED)

    gold_pad = size * 0.012
    rounded_square(d, [card_box[0] - gold_pad, card_box[1] - gold_pad,
                        card_box[2] + gold_pad, card_box[3] + gold_pad],
                    radius=card_size * 0.15, fill=GOLD)

    rounded_square(d, card_box, radius=card_size * 0.14, fill=PLATE)

    star_outer = card_size * 0.34
    draw_star(d, cx, cy, star_outer, GOLD)
    draw_star(d, cx, cy, star_outer * 0.78, BLACK_STAR)

    return img


def save(img, path):
    img.save(path)
    print("wrote", path, img.size)


def build_adaptive_foreground():
    sizes = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
    for density, px in sizes.items():
        img = icon_card(px, include_background=False)
        save(img, f"{OUT}/mipmap-{density}/ic_launcher_foreground.png")


def build_legacy_launcher():
    sizes = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
    for density, px in sizes.items():
        img = icon_card(px, include_background=True)
        save(img, f"{OUT}/mipmap-{density}/ic_launcher.png")
        save(img, f"{OUT}/mipmap-{density}/ic_launcher_round.png")


def build_store_icon():
    img = icon_card(512, include_background=True).convert("RGB")
    save(img, "/home/claude/agroo-memory-android/assets-src/play-store-icon-512.png")


def build_feature_graphic():
    W, H = 1024, 500
    img = Image.new("RGB", (W, H), PLATE)
    d = ImageDraw.Draw(img)

    # Subtle vertical gradient plate -> plate2 for depth
    for y in range(H):
        t = y / H
        r = int(PLATE[0] + (PLATE_2[0] - PLATE[0]) * t)
        g = int(PLATE[1] + (PLATE_2[1] - PLATE[1]) * t)
        b = int(PLATE[2] + (PLATE_2[2] - PLATE[2]) * t)
        d.line([(0, y), (W, y)], fill=(r, g, b))

    # Mini flag + star badge on the left
    badge_w, badge_h = 190, 130
    bx, by = 70, (H - badge_h) // 2
    band_h = badge_h / 3
    d.rounded_rectangle([bx, by, bx + badge_w, by + badge_h], radius=14, fill=GOLD)
    d.rectangle([bx, by, bx + badge_w, by + band_h], fill=RED)
    d.rectangle([bx, by + 2 * band_h, bx + badge_w, by + badge_h], fill=GREEN)
    draw_star(d, bx + badge_w / 2, by + badge_h / 2, badge_h * 0.22, BLACK_STAR)
    d.rounded_rectangle([bx, by, bx + badge_w, by + badge_h], radius=14, outline=GOLD, width=4)

    # Title + tagline -- auto-shrink the title so it always fits the banner
    title_path = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
    tag_font = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 28)

    text_x = bx + badge_w + 50
    right_margin = 60
    max_text_w = W - right_margin - text_x
    title_text = "Agroo-Memory Card"

    size = 84
    title_font = ImageFont.truetype(title_path, size)
    bbox = d.textbbox((0, 0), title_text, font=title_font)
    while (bbox[2] - bbox[0]) > max_text_w and size > 30:
        size -= 2
        title_font = ImageFont.truetype(title_path, size)
        bbox = d.textbbox((0, 0), title_text, font=title_font)
    title_h = bbox[3] - bbox[1]

    block_h = title_h + 14 + 30
    title_y = (H - block_h) / 2 - bbox[1]
    d.text((text_x, title_y), title_text, font=title_font, fill=GOLD)
    tag_y = title_y + bbox[1] + title_h + 18
    d.text((text_x, tag_y), "A Black Star–inspired memory match", font=tag_font, fill=CREAM)

    # A quiet row of flag-colored accent dots under the tagline, echoing the confetti
    dot_y = tag_y + 46
    dot_r = 6
    for i, col in enumerate([RED, GOLD, GREEN]):
        dot_x = text_x + i * (dot_r * 2 + 14)
        d.ellipse([dot_x - dot_r, dot_y - dot_r, dot_x + dot_r, dot_y + dot_r], fill=col)

    save(img, "/home/claude/agroo-memory-android/assets-src/feature-graphic-1024x500.png")


def build_splash():
    sizes = {
        "drawable": (480, 320),
        "drawable-port-mdpi": (320, 480),
        "drawable-port-hdpi": (480, 800),
        "drawable-port-xhdpi": (720, 1280),
        "drawable-port-xxhdpi": (960, 1600),
        "drawable-port-xxxhdpi": (1280, 1920),
        "drawable-land-mdpi": (480, 320),
        "drawable-land-hdpi": (800, 480),
        "drawable-land-xhdpi": (1280, 720),
        "drawable-land-xxhdpi": (1600, 960),
        "drawable-land-xxxhdpi": (1920, 1280),
    }
    for folder, (w, h) in sizes.items():
        img = Image.new("RGB", (w, h), PLATE)
        d = ImageDraw.Draw(img)
        short_side = min(w, h)

        badge_h = short_side * 0.24
        badge_w = badge_h * 1.5
        bx = (w - badge_w) / 2
        by = h * 0.42 - badge_h / 2
        band_h = badge_h / 3
        d.rounded_rectangle([bx, by, bx + badge_w, by + badge_h], radius=badge_h * 0.11, fill=GOLD)
        d.rectangle([bx, by, bx + badge_w, by + band_h], fill=RED)
        d.rectangle([bx, by + 2 * band_h, bx + badge_w, by + badge_h], fill=GREEN)
        draw_star(d, bx + badge_w / 2, by + badge_h / 2, badge_h * 0.22, BLACK_STAR)
        d.rounded_rectangle([bx, by, bx + badge_w, by + badge_h], radius=badge_h * 0.11,
                             outline=GOLD, width=max(2, int(short_side * 0.006)))

        title = "Agroo-Memory Card"
        size = int(short_side * 0.075)
        size = max(size, 14)
        font = ImageFont.truetype("/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf", size)
        bbox = d.textbbox((0, 0), title, font=font)
        max_w = w * 0.86
        while (bbox[2] - bbox[0]) > max_w and size > 10:
            size -= 2
            font = ImageFont.truetype("/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf", size)
            bbox = d.textbbox((0, 0), title, font=font)
        tw = bbox[2] - bbox[0]
        ty = by + badge_h + short_side * 0.09
        d.text(((w - tw) / 2, ty), title, font=font, fill=GOLD)

        path = f"{OUT}/{folder}/splash.png"
        save(img, path)


if __name__ == "__main__":
    build_adaptive_foreground()
    build_legacy_launcher()
    build_store_icon()
    build_feature_graphic()
    build_splash()
