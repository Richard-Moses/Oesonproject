# Agroo-Memory Card — Android build & Play Store guide

This covers turning the project in this folder into a signed app bundle and
getting it onto the Play Store. I built and statically checked the project
here, but I can't actually compile Android apps or hold a Google Play
account, so the build and the submission itself happen on your machine.

## What's in this folder

- `android/` — the Android Studio project. This is the one you'll open.
- `www/` and `capacitor.config.ts` / `package.json` — the web source that
  feeds the app. You only touch these if you want to change the game later
  and re-sync (see "Updating the game later" below).
- `assets-src/` — the Play Store listing images (icon, feature graphic,
  screenshots) and the scripts that generated them.
- This guide.

## 1. Open and build the project

1. Install [Android Studio](https://developer.android.com/studio) if you
   don't have it already.
2. **File → Open**, pick the `android` folder (not the parent folder).
3. Let Gradle sync — first sync downloads the Android Gradle Plugin and SDK
   platform, so it needs your normal internet connection and will take a
   few minutes.
4. Run **Build → Make Project**. If that succeeds, the app itself is sound.
5. To try it: **Run ▶** with an emulator or your own phone plugged in over
   USB (with Developer Options → USB debugging on).

If Gradle sync complains about a missing SDK platform or build-tools
version, click the "Install missing platform(s)" link it offers — that's
normal on a first-time setup.

## 2. Generate a signing key

Play Store requires every app to be signed. Generate a keystore once and
keep it safe — if you lose it, you can never update this app again under
the same listing.

In Android Studio: **Build → Generate Signed Bundle / APK → Android App
Bundle → Create new...**, then fill in a keystore path (somewhere outside
this project folder, e.g. `Documents\keystores\agroo-memory.jks`), a
password, and your name/organization for the certificate. Store both
passwords in a password manager — Google can't recover them for you.

## 3. Build the release bundle

Same dialog, continue through with your new (or existing) keystore,
choose **release** as the build variant, and check both signature versions
(V1 and V2) if asked. This produces an `.aab` file under
`android/app/release/`. That `.aab` is what you upload to Play Console —
not an APK.

Before shipping, bump `versionCode` and `versionName` in
`android/app/build.gradle` for any future update (versionCode must
increase every single release; versionName is just the human-readable
label like "1.1").

## 4. Set up the Play Console listing

You'll need your own Google Play Developer account (one-time $25 fee) at
[play.google.com/console](https://play.google.com/console). Create a new
app there, then fill in:

**App details**
- App name: `Agroo-Memory Card`
- Short description (max 80 chars): `A Black Star–inspired memory card
  matching game, three board sizes.`
- Full description (max 4000 chars) — a draft to start from:

  > Agroo-Memory Card is a farm-stand themed memory matching game dressed
  > in the red, gold, and green of Ghana's flag, with a black star on
  > every card back. Flip two cards at a time to find matching produce —
  > tomatoes, carrots, corn, and more — and clear the crate.
  >
  > • Three board sizes: Small, Classic, and Big
  > • Move counter and timer so you can beat your own best round
  > • A burst of applause every time you find a pair
  > • Fully offline — no account, no ads, no data collection
  > • Designed for one-handed play on any phone screen

**Graphics** (all in `assets-src/`)
- App icon: `play-store-icon-512.png` (512×512)
- Feature graphic: `feature-graphic-1024x500.png` (1024×500)
- Phone screenshots: `screenshot-1-board.png`, `screenshot-2-flip.png`,
  `screenshot-3-win.png` (Play Store wants at least 2; these 3 cover the
  board, a mid-flip, and the win screen)

**Privacy policy URL**
I drafted one and published it here:
https://claude.ai/code/artifact/d0b556db-5079-4d99-80b2-3697365ecefc

Two things before you use that link: it's private until you open it and
hit **Share** (top right) to make it public — Play's reviewers need to be
able to load it without logging in. And it currently has a placeholder
where a contact email should go — edit that in before you publish, or ask
me to swap in a real address and I'll republish it in place.

**Data safety form**
Since the app collects nothing and has no network access, you can answer
"No" to every data-collection question in this section — it's a genuinely
easy form for this app.

**Content rating questionnaire**
This is a simple family-friendly matching game with no violence, no user
communication, and no purchases — it should land in the lowest rating
tier (e.g. "Everyone" / PEGI 3) once you answer the standard questionnaire
honestly.

**App category**: Games → Casual (or Puzzle) fits well.

## 5. Recommended: internal testing first

Before a public release, use Play Console's **Internal testing** track —
upload the same `.aab`, add your own email as a tester, and install it via
the opt-in link Google gives you. This confirms the store listing and
signed build both work before anyone else sees it, and it's the fastest
track to approve (usually minutes, not days).

## 6. Submit for review

Once internal testing looks right, promote the release to **Production**
(or start there directly with a "Closed testing" or staged rollout if you
prefer caution). Google's review for a first submission commonly takes
anywhere from a few hours to a few days.

## Updating the game later

If you (or I, in a future session) change `www/index.html`:

```
npm install
npx cap sync android
```

then reopen/rebuild in Android Studio. This copies the updated web file
into `android/app/src/main/assets/public/` and re-applies any native
config changes.

## Notes on what this build deliberately leaves out

- **No internet permission.** The game doesn't need it — everything
  (including the applause sound) is generated on-device. This also keeps
  the Play data-safety form simple.
- **No custom webfonts.** The in-game "Alfa Slab One" / "Karla" look is
  only available where Google Fonts can be fetched (the web/artifact
  version); the app falls back to the system serif/sans-serif fonts
  instead of bundling font files. Cosmetic only — nothing else changes.
- **Portrait-locked.** The board is designed as a centered vertical stack;
  locking orientation keeps every phone size looking intentional rather
  than stretched sideways.
