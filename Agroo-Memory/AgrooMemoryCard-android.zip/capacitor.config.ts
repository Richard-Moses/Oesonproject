import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.agroo.memorycard',
  appName: 'Agroo-Memory Card',
  webDir: 'www'
};

export default config;
